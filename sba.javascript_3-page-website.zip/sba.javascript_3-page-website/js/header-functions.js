// import jquery-3.4.0
document.write('<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>');
document.write('<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>');

// import `utils.js`
document.write('<script type="text/javascript" src="./js/utils.js"></script>');



// import w3-include
document.write('<script src="http://www.w3schools.com/lib/w3data.js"></script>');
